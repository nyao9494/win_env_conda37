import FreeCAD,FreeCADGui,Part

minl = 0.8 # 0.8 millimeters is the minimum line size that Revit is able to swallow. Pitiful, I know...
edges = []

if FreeCAD.ActiveDocument:
  for o in FreeCAD.ActiveDocument.Objects:
	  if o.ViewObject.Visibility == True:
		  if o.isDerivedFrom("Part::Feature"):
			  if o.Shape:
				  for e in o.Shape.Edges:
					  if e.Length <= minl:
						  edges.append(e)
if edges:
	result = Part.makeCompound(edges)
	Part.show(result)
	FreeCADGui.Selection.clearSelection()
	r = FreeCAD.ActiveDocument.Objects[-1]
	r.ViewObject.LineWidth = 3
	FreeCADGui.Selection.addSelection(r)